<?php 


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$hostname = 'localhost:3306';
$username = 'root';
$password = '';
$database = 'core_test';

$conn =  mysqli_connect($hostname, $username, $password, $database);

if(!$conn)
{
	die('Could not connect: '. mysqli_connect_error());
}

 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registration Form</title>
	<style type="text/css">
		
		.form-field {
		  padding: 6px;
		}

		.text-error {
			  color: red;
			}
	</style>
</head>
<body>

	<?php

	$name_error 	 = '';
	$phone_error  	 = '';
	$email_error  	 = '';
	$subject_error   = '';
	$message_error   = '';

	$name 	 = '';
	$phone 	 = '';
	$email 	 = '';
	$subject = '';
	$message = '';

	if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register']))
	{
		$name 	 = $_POST['name'];
		$phone 	 = $_POST['phone'];
		$email 	 = $_POST['email'];
		$subject = $_POST['subject'];
		$message = $_POST['message'];
		$validate_count = 1;
		$email_status = 2; // want to enable email add status =1 

		if(empty($name))
		{
			$name_error = 'Full name is required!';
			$validate_count++;
		}
		else{

			$name = validate($_POST['name']);
			if(!preg_match('/[^a-zA-Z ]*$/', $name)){
				$name_error = 'Only letter and spaces allowed!';
				$validate_count++;
			}
		}

		if(empty($phone))
		{
			$phone_error = 'Phone Number is required!';
			$validate_count++;
		}
		else{

			$phone = validate($_POST['phone']);
			if(!preg_match('/^[0-9]{10}+$/', $phone)){
				$phone_error = 'Only numeric value allowed with 10 digit';
				$validate_count++;
			}
		}


		if(empty($email))
		{
			$email_error = 'Email is required!';
			$validate_count++;
		}
		else{

			$email = validate($_POST['email']);
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
				$email_error = 'Email format is not correct!';
				$validate_count++;
			}
		}

		if(empty($subject))
		{
			$subject_error = 'Subject is required!';
			$validate_count++;
		}
		else{

			$subject = validate($_POST['subject']);
		}

		if(empty($message))
		{
			$message_error = 'Message is required!';
			$validate_count++;
		}
		else{

			$message = validate($_POST['message']);
		}


		if($name && $phone && $email && $subject && $message && $validate_count == 1)
		{
			$sql = 'INSERT INTO `users` (`name`, `phone`, `email`, `subject`, `message`) VALUES ("'.$name.'", "'.$phone.'", "'.$email.'", "'.$subject.'", "'.$message.'");';

				if(mysqli_query($conn, $sql))
				{
					echo "Registration is successfull!";
					$name 	 = '';
					$phone 	 = '';
					$email 	 = '';
					$subject = '';
					$message = '';

					if($email_status == 1){

						try {
						    //Server settings
						    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
						    $mail->isSMTP();                                            //Send using SMTP
						    $mail->Host       = ''; //Set the SMTP server to send through
						    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
						    $mail->Username   = '';  //SMTP username
						    $mail->Password   = '';                //SMTP password
						    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
						    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

						    //Recipients
						    $mail->setFrom('', 'Core Test');
						    $mail->addAddress('', 'Admin');        //Add a recipient aabcd@domain.com
						    //$mail->addAddress('ellen@example.com');                 //Name is optional
						    $mail->addReplyTo('', 'Core Test');
						    #$mail->addCC('cc@example.com');
						    #$mail->addBCC('bcc@example.com');

						     //Attachments
						     #$mail->addAttachment('AMARA-Ebrochure-V1.18-08.pdf');    //Add attachments
						     #$mail->addAttachment('/tmp/image.jpg', 'new.jpg');       //Optional name

						    //Content
						    $mail->isHTML(true);                                       //Set email format to HTML
						    $mail->Subject = $subject;
						    $mail->Body    =  $message;
						    #$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

						    $mail->send();
						    
						    echo true;
						} catch (Exception $e) {
						    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
						    echo false;
						}
					}
				}
				else
				{
					echo "somethinf went wrong, please try again";
				}
		}

		mysqli_close($conn);
		
	}

	function validate($data)
		{
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
	?>

	<h2>Registration Form</h2>

	<form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
	
		<div class="form-field">
			<label>Full Name</label>
			<input type="text" name="name" value="<?= $name ?>">
			<p class="text-error"><?= $name_error ?></p>
		</div>

		<div class="form-field">
			<label>Phone Number</label>
			<input type="text" name="phone" value="<?= $phone ?>">
			<p class="text-error"><?= $phone_error ?></p>
		</div>

		<div class="form-field">
			<label>Email</label>
			<input type="email" name="email" value="<?= $email ?>">
			<p class="text-error"><?= $email_error ?></p>
		</div>

		<div class="form-field">
			<label>Subject</label>
			<input type="text" name="subject" value="<?= $subject ?>">
			<p class="text-error"><?= $subject_error ?></p>
		</div>

		<div class="form-field">
			<label>Message</label>
			<textarea name="message" rows="4"><?= $message ?></textarea>
			<p class="text-error"><?= $message_error ?></p>
		</div>

			<div class="form-field">
				<button type="submit" name="register">Submit</button>
				<button type="reset">Reset</button>
			</div>


	</form>

</body>
</html>